<script type="text/javascript">
	window.location.href = "public";
</script>