<?php

return [

	'attribute'			=> 'Attribute',
	'attributes'		=> 'Attributes',
	'attribute_set'		=> 'Attribute Set',
	'attribute_sets'	=> 'Attribute Sets',
	'name'				=> 'Name',
	'type'				=> 'Type',
	'text'				=> 'Text',
	'textarea'			=> 'Text Area',
	'date'				=> 'Date',
	'multiple_select'	=> 'Multiple Select',
	'dropdown'			=> 'Dropdown',
	'media'				=> 'Media',
	'add_option'		=> 'Add option',
	'option'			=> 'Option',
	'default'			=> 'Default',
];