<?php

return [

	'client'                => 'Client',
	'clients'               => 'Clients',
	'email'                 => 'E-mail',
	'name'                  => 'Name',
	'salutation'            => 'Salutation',
	'birthday'				=> 'Birthday',
	'gender'                => 'Gender',
	'male'                  => 'Male',
	'female'                => 'Female',
	'password'              => 'Password',
	'password_confirmation' => 'Password Confirmation',

	// Tabs
	'tab_general'			=> 'General',
	'tab_permissions'		=> 'Permissions',
	'tab_address'			=> 'Address',
	'tab_company'			=> 'Company',
];