<?php

return [

	'carrier'		=> 'Carrier',
	'carriers'		=> 'Carriers',
	'name'			=> 'Name',
	'price'			=> 'Price',
	'delivery_text'	=> 'Delivery Text',
	'logo'			=> 'Logo'

];