<?php

return [

	'currency'				=> 'Currency',
	'currencies'			=> 'Currencies',
	'iso'					=> 'ISO',
	'name'					=> 'Name',
	'value'					=> 'Value',
	'default'				=> 'Default',
	'no_default_currency'	=> 'No default currency defined',

];