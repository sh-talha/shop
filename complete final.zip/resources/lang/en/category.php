<?php

return [

	'category'		=> 'Category',
	'categories'	=> 'Categories',
	'parent'		=> 'Parent',
	'name'			=> 'Name',
	'slug'			=> 'Slug',

];