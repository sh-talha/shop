<?php

return [
	'notification_template'  => 'Notification Template',
	'notification_templates' => 'Notification Templates',
	'name'                   => 'Name',
	'slug'                   => 'Slug',
	'model'                  => 'Model',
	'body'                   => 'Body',
	'available_variables'    => 'Available variables',
	'variables_error'        => 'Please check template variables'
];