<?php

return [

	'add'              => 'Add',
	'cancel'           => 'Cancel',
	'edit'             => 'Edit',
	'delete'           => 'Delete',
	'status'           => 'Status',
	'inactive'         => 'Inactive',
	'active'           => 'Active',
	'no'               => 'No',
	'yes'              => 'Yes',
	'close'            => 'Close',
	'open'             => 'Open',
	'fail'             => 'Fail',
	'success'          => 'Success',
	'action'           => 'Action',
	'actions'          => 'Actions',
	'error_occurred'   => 'An error has occurred',
	'must_be_unique'   => 'Must be unique',
	'loading_ellipsis' => 'Loading...',
	'view'             => 'View',
	'year'             => 'Year',
	'years'            => 'Years',
	'date'             => 'Date',
	'total'            => 'Total',

];