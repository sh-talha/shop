<?php

return [

	'tax'			=> 'Tax',
	'taxes'			=> 'Taxes',
	'name'			=> 'Name',
	'value'			=> 'Value',
	'hint_value'	=> 'Use dot (.) instead comma (,) for separating number decimals',

];