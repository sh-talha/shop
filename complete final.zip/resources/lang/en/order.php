<?php

return [

	'order'                   => 'Order',
	'orders'                  => 'Orders',
	'order_status'            => 'Order Status',
	'order_statuses'          => 'Order Statuses',
	'status'                  => 'Status',
	'status_name'             => 'Status Name',
	'notification'	  		  => 'Notification',
	'no_status_history'       => 'No status history',
	'no_order_statuses'       => 'No order statuses defined',
	'update_status'           => 'Update status',
	'status_updated'          => 'Order status updated!',
	'created_at'              => 'Created at',
	'shipping_cost'           => 'Shipping cost',
	'shipping_details'        => 'Shipping details',
	'shipping_address'        => 'Shipping address',
	'billing_info'            => 'Billing info',
	'billing_address'         => 'Billing address',
	'billing_company_details' => 'Billing company details',
	'quantity'                => 'Quantity',

];