@extends('website_layout.layout')
@section('body')
<!-- Start Banner Area -->
<section class="banner-area organic-breadcrumb">
    <div class="container">
    </div>
</section>

<!--================Login Box Area =================-->
	<section class="login_box_area section_gap" style="margin-top: -150px !important">
		<div class="container">
			<h2 style="text-align:center;" >About Us</h2>
			<div class="row">
				<h1 style="color: #5e9ca0;">Granyupon.com</h1>
				<h2 style="color: #2e6c80;">Que es granyupon.com:</h2>
				<p>Granyupon.com es un portal (p&aacute;gina web) dedicada a hacer de intermediario entre compradores y vendedores,velando por el inter&eacute;s de estos.</p>
				<p>En nuestra web encontraras un sinf&iacute;n de prendas para vestir, como calzado tanto para mujeres como para hombres.</p>
				<p>En nuestra web podr&aacute;s encontrar un sinf&iacute;n de productos relacionados con la moda y el textil.</p>
				<h2 style="color: #2e6c80;">&iquest;Qu&eacute; puedes encontrar en Granyupon?</h2>
				<ul style="list-style-type: disc;">
				<li>Calzado</li>
				<li>Complementos</li>
				<li>Textiles Varios</li>
				<li>Ropa de deporte</li>
				<li>Ofertas en prendas de Vestir</li>
				<li>Y mucho m&aacute;s</li>
				</ul>
				<p>&nbsp; &nbsp; &nbsp; &nbsp;</p>
				<h2 style="color: #2e6c80;">Tambien puedes vender:</h2>
				<p>Puedes disponer de nuestra web para vender tus productos o prendas que ya no utilices Solo tienes que registrarte desde el apartado de vendedor.</p>

			</div>
		</div>
	</section>

@endsection
