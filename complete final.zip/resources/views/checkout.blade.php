@extends('website_layout.layout')
@section('body')
<!-- Start Banner Area -->
<section class="banner-area organic-breadcrumb">
    <div class="container">
    </div>
</section>
<!-- End Banner Area -->
<!--================Checkout Area =================-->
<section class="checkout_area section_gap">

    <div class="container" style="margin-top: -120px">

        <h2 style="text-align:left;">Billing Address</h2>
        <div class="billing_details" >
            <div class="row">
                <div class="col-lg-8" style="border: 3px solid #ECECEC;"><br>
                    <h3>Billing Details</h3>
                    <form class="row contact_form" action="{{url('confirmation')}}" method="get" novalidate="novalidate">
                        {{ csrf_field() }}
                        <div class="col-md-6 form-group p_star">
                            <input type="text" class="form-control " placeholder="Firstname" id="Firstname" name="firstname" value="{{Auth::user()->name}}">
                            {{-- <span class="placeholder" data-placeholder="First name"></span> --}}
                        </div>
                        <div class="col-md-6 form-group p_star">
                            <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Lastname">
                            {{-- <span class="placeholder" data-placeholder="Last name"></span> --}}
                        </div>
                       {{--  <div class="col-md-12 form-group">
                            <input type="text" class="form-control" id="company" name="company" placeholder="Company name">
                        </div> --}}
                        <div class="col-md-6 form-group p_star">
                            <input type="text" class="form-control" id="emailaddress" name="emailaddress" placeholder="Email Address" value="{{Auth::user()->email}}">
                            {{-- <span class="placeholder" data-placeholder="Email Address"></span> --}}

                        </div>
                        <div class="col-md-6 form-group p_star">
                            <input type="text" class="form-control " id="phonenumber" name="phonenumber" placeholder="Phone number"><br>
                            {{-- <span class="placeholder" data-placeholder="Phone number"></span> --}}
                            <div class="alert alert-warning error_class" role="alert" id="phone_error">
                              Please Enter Phone No
                            </div>
                        </div>
                        <div class="col-md-12 form-group p_star">
                            {{-- <label for="exampleInputEmail1">Country</label> --}}
                            <select class="form-control" name="country" id="countries" >
                                 <option  value="">Select Country</option>
                               @foreach($countries as $view_countries)
                                <option  value="{{$view_countries->id}}">{{$view_countries->name}}</option>
                               @endforeach
                            </select><br>
                            <div class="alert alert-warning error_class" role="alert" id="country_error">
                              Please select country
                            </div>
                        </div>

                        <div class="col-md-12 form-group p_star">
                           {{-- <label for="exampleInputEmail1">State</label> --}}
                           <div id="state">
                              <select class="form-control" name="city" >
                                 <option value="">Select State</option>}
                                 
                              </select>

                           </div>
                        </div>

                        <div class="col-md-12 form-group p_star">
                            <input type="text" class="form-control" id="add1" name="add1" placeholder="Address line 01">
                            {{-- <span class="placeholder" data-placeholder="Address line 01"></span> --}}

                        </div>
                        <div class="col-md-12" >
                            <div class="alert alert-warning error_class" id="address_error" role="alert">
                              Please Enter address.
                            </div>
                        </div>

                        <div class="col-md-12 form-group p_star">
                            <input type="text" class="form-control" id="add2" name="add2" placeholder="Address line 02">
                            {{-- <span class="placeholder" data-placeholder="Address line 02"></span> --}}
                        </div>
                        <div class="col-md-12 form-group">
                            <input type="text" class="form-control" id="zip" name="zip" placeholder="Postcode/ZIP">
                        </div>
                        <div class="col-md-12">
                            <div class="alert alert-warning error_class" id="zip_error" role="alert">
                              Please Enter Postal Code.
                            </div>
                        </div>
                        <input type="text" name="price" id="total_price_pro" style="display: none">
                        <input type="submit" name="" id="form_submit" style="display: none">
                        {{-- <div class="col-md-12 form-group">
                            <div class="creat_account">
                                <h3>Shipping Details</h3>
                                <input type="checkbox" id="f-option3" name="selector">
                                <label for="f-option3">Ship to a different address?</label>
                            </div>
                            <textarea class="form-control" name="message" id="message" rows="1" placeholder="Order Notes"></textarea>
                        </div> --}}
                    </form>
                </div>
                <div class="col-lg-4">
                    <div class="order_box">
                        <h2>Your Order</h2>
                      
                        <ul class="list">
                            <li><a href="#"> Product<span>Total</span></a></li>
                            <?php $total = 0 ?>

                            @if(session('cart'))
                                @foreach(session('cart') as $id => $details)
                                    <?php $total += $details['price'] * $details['quantity'] ?>
                                        <li>
                                            {{-- <a href="#">{{ $details['name'] }} --}}
                                                <span style="color: black; display: inline-block;width: 80px;">{{ $details['name'] }}</span> 
                                                <span class="middle col-md-2" >{{$details['price']}}</span> 
                                                <span class="middle col-md-2">x{{ $details['quantity'] }}</span> 
                                                <span class="last col-md-2">${{ $details['price'] * $details['quantity'] }}</span><br>
                                            {{-- </a> --}}
                                        </li>
                                @endforeach
                            @endif
                        </ul>

                        <ul class="list list_2">
                            {{-- <li><a href="#">Subtotal <span>{{ $total }}</span></a></li>
                            <li><a href="#">Shipping <span>Flat rate: $50.00</span></a></li> --}}
                            <li><a href="#" >Total <span id="total_price">{{ $total }}</span></a></li>
                        </ul>
                        <div class="creat_account">
                            <input type="checkbox" id="f-option4" name="selector">
                            <label for="f-option4">I’ve read and accept the </label>
                            <a href="#">terms & conditions*</a>
                        </div>
                        <a class="primary-btn" id="validation_button">Proceed to Payment</a>
                    </div>
                </div>
            </div><br>
                <div class="row">
                    <button class="btn btn-warning "><a href="{{ url('/cart') }}" style="color: black" ><i class="fa fa-angle-left"></i> Back</a></button>
                </div>
                    
            
        </div>
    </div>
</section>

<!--================End Checkout Area =================-->
@endsection

@section('activate')
<script>
     ActiveMenu(6);
</script>
@endsection
