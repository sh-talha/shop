@extends('website_layout.layout')
@section('body')

<!-- Start Banner Area -->
<section class="banner-area organic-breadcrumb">
    <div class="container">
    </div>
</section>
<style type="text/css">
	#description_p {
	       
	     height: 190px;
	     /*white-space: nowrap;*/
	     overflow: hidden;
	     text-overflow: ellipsis;
	}
	.img-upload-btn { 
	    position: relative; 
	    overflow: hidden; 
	    padding-top: 95%;
	} 

	.img-upload-btn input[type=file] { 
	    position: absolute; 
	    top: 0; 
	    right: 0; 
	    min-width: 100%; 
	    min-height: 100%; 
	    font-size: 100px; 
	    text-align: right; 
	    filter: alpha(opacity=0); 
	    opacity: 0; 
	    outline: none; 
	    background: white; 
	    cursor: inherit; 
	    display: block; 
	} 

	.img-upload-btn i { 
	    position: absolute;
	    height: 56px;
	    width: 56px;
	    top: 50%;
	    left: 50%;
	    margin-top: -8px;
	    margin-left: -8px;
	}

	.btn-radio {
	    position: relative; 
	    overflow: hidden; 
	}

	.btn-radio input[type=radio] { 
	    position: absolute; 
	    top: 0; 
	    right: 0; 
	    min-width: 100%; 
	    min-height: 100%; 
	    font-size: 100px; 
	    text-align: right; 
	    filter: alpha(opacity=0); 
	    opacity: 0; 
	    outline: none; 
	    background: white; 
	    cursor: inherit; 
	    display: block; 
	}
	.class_size_vendor:hover{
		background-color: #45D830;
		color: white;
		cursor: pointer;
	}
	.class_size_color{
		background-color: #45D830;
		color: white;
	}
	.class_img_vendor_active:hover{
		padding: .25rem;
	    background-color: #45D830;
	    border: 1px solid #dee2e6;
	    border-radius: .25rem;
	}
	.vendor_active{
		padding: .25rem;
	    background-color: #45D830;
	    border: 1px solid #dee2e6;
	    border-radius: .25rem;
	}
</style>

<!--================Single Product Area =================-->

	<div class="product_image_area" style="margin-top: -150px">
		<div class="container">
			<div class="row s_product_inner">
				
				<div class="col-lg-6">
					<div class="s_Product_carousel">
						@foreach($products as $products)
						<div class="single-prd-items">
							<img class="img-fluid"src="{{ asset('uploads/products/'.substr($products->Products_id, 0, 1).'/'.$products->Products_id.'/'.$products->product_image)}}" alt="">
						</div>
						@if($loop->last)
					        <div class="single-prd-item">
    							<img class="img-fluid"src="{{ asset('uploads/products/'.substr($products->Products_id, 0, 1).'/'.$products->Products_id.'/'.$products->product_image)}}" alt="">
    						</div>
					    @endif
						
						{{-- <div class="single-prd-item">
							<img class="img-fluid"src="{{ asset('uploads/products/'.substr($products->Products_id, 0, 1).'/'.$products->Products_id.'/'.$products->product_image)}}" alt="">
						</div> --}}
						@endforeach
					</div>
				</div>
				
				<div class="col-lg-5 offset-lg-1">
					<form method="get">
						 {{ csrf_field() }}

						<div class="s_product_text">
							<h3>{{$products->product_name}}</h3>
							{{-- <h2>{{$products->price}}</h2> --}}
							<div class="row">
								<?php  $special=\App\Models\SpecificPrice::where(['product_id' =>$products->Products_id])->pluck('reduction')->last() ?>
								@if($special == 0 )
									<div class="col-md-4">
										<h2>${{$products->price}}</h2>
									</div>
								@else
									<div class="col-md-4">
										<h2>${{$special}}</h2>
									</div>
									<div class="col-md-4">
										<s><h2>${{$products->price}}</h2></s>
									</div>
								@endif
								
								
							</div>

							<ul class="list">
								<li><a href="#"><span>Availibility</span> : {{($products->price > 0) ? 'In Stock' : 'Out of Stock' }}</a></li>
							</ul>
							<p id="description_p">{{$products->description}}</p>
							@if($vendor_count != null)
							<div class="product_count" style="margin-top: -50px;display: none">
								<label for="color">Color:</label>
								<select name="color" class="form-control" id="img_change">
									<option value="0">Select Color</option>
									@foreach($products_vendor as $viewproducts_vendor)
										<option value="{{$viewproducts_vendor->vendo_product_id}}">{{$viewproducts_vendor->color}}</option>
									@endforeach
								</select>
							</div>
							@endif

							<div class="product_count" style="margin-top: -100px;display: none" >
								<label for="size">Size:</label>
								<select name="size" class="form-control" id="size">
									<option value="0">Select Size</option>
									@foreach($color as $viewcolor)
					                 	<option value="{{$viewcolor->value}}">{{$viewcolor->value}}</option>
					              	 @endforeach

								</select>
							</div>
							<div class="product_count">
								<label for="qty">Quantity:</label>
								<input type="number" name="qty" maxlength="12" min="1" value="1" title="Quantity:" id="quantity" class="input-text qty">
							</div>
							<input class="form-control" type="text" name="img_url_insert"  id="img_url_insert" style="display: none">

							@if($vendor_count != null)
							<div class="col-md-8" style="margin-left: -14px">
								<label for="qty">Color:</label>
								<div class="row">
									@foreach($products_vendor as $viewproducts_vendor)
									
									<div class="col-md-4 class_img_vendor_active " id="active_{{$viewproducts_vendor->vendo_product_id}}">
										
									<img class="img-fluid img-thumbnail img_class_hide class_img_vendor"src="
									{{ asset(Storage::url('upload/vendor_products/'.$viewproducts_vendor->image))}}" alt="" style="width: 100px;display: nones" id="item_img_{{$viewproducts_vendor->vendo_product_id}}">
									</div>
									@endforeach
									
								</div>
							</div>
							@endif
							<div class="col-md-8" style="margin-left: -14px"><br>
								<label for="qty">Size:</label>
								<div class="row" style="margin-left: 2px">
									@foreach($color as $viewcolor)
									<div class="col-md-3 img-thumbnail class_size_vendor" style="margin-right: 10px;margin-top: 10px" id="{{$viewcolor->value}}">
										<span >{{$viewcolor->value}}<br></span>

									</div>
									@endforeach
									
								</div>
							</div>
							<div class="card_area d-flex align-items-center "><br><br>
								<a class="primary-btn cart_class_s " id="{{$products->Products_id}}">Add</a>

								<a class="btn btn-light report_class" id="{{$products->Products_id}}">Report the product</a>

								<a class="social-info wish_class" data-wish='{{$products->Products_id}}'>
								       <span class="fa fa-heart" style="font-size: 20px;padding-left: 50px"></span>
								   </a>
								
							</div>

						</div>
					</form>
				
				</div>
			</div>
		</div>
	</div>
	
	<!--================End Single Product Area =================-->

	<!--================Product Description Area =================-->
	<section class="product_description_area">
		<div class="container">
			<ul class="nav nav-tabs" id="myTab" role="tablist">
				<li class="nav-item">
					<a class="nav-link" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Description</a>
				</li>
				{{-- <li class="nav-item">
					<a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile"
					 aria-selected="false">Specification</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact"
					 aria-selected="false">Comments</a>
				</li> --}}
				<li class="nav-item">
					<a class="nav-link active" id="review-tab" data-toggle="tab" href="#review" role="tab" aria-controls="review"
					 aria-selected="false">Reviews</a>
				</li>
			</ul>
			<div class="tab-content" id="myTabContent">
				<div class="tab-pane fade" id="home" role="tabpanel" aria-labelledby="home-tab">
					<p>{{$products->description}}</p>
				</div>
				<div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
					<div class="table-responsive">
						<table class="table">
							<tbody>
								<tr>
									<td>
										<h5>Width</h5>
									</td>
									<td>
										<h5>128mm</h5>
									</td>
								</tr>
								<tr>
									<td>
										<h5>Height</h5>
									</td>
									<td>
										<h5>508mm</h5>
									</td>
								</tr>
								<tr>
									<td>
										<h5>Depth</h5>
									</td>
									<td>
										<h5>85mm</h5>
									</td>
								</tr>
								<tr>
									<td>
										<h5>Weight</h5>
									</td>
									<td>
										<h5>52gm</h5>
									</td>
								</tr>
								<tr>
									<td>
										<h5>Quality checking</h5>
									</td>
									<td>
										<h5>yes</h5>
									</td>
								</tr>
								<tr>
									<td>
										<h5>Freshness Duration</h5>
									</td>
									<td>
										<h5>03days</h5>
									</td>
								</tr>
								<tr>
									<td>
										<h5>When packeting</h5>
									</td>
									<td>
										<h5>Without touch of hand</h5>
									</td>
								</tr>
								<tr>
									<td>
										<h5>Each Box contains</h5>
									</td>
									<td>
										<h5>60pcs</h5>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
				<div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
					<div class="row">
						<div class="col-lg-6">
							<div class="comment_list">
								<div class="review_item">
									<div class="media">
										<div class="d-flex">
											<img src="{{ asset('img/product/review-1.png')}}" alt="">
										</div>
										<div class="media-body">
											<h4>Blake Ruiz</h4>
											<h5>12th Feb, 2018 at 05:56 pm</h5>
											<a class="reply_btn" href="#">Reply</a>
										</div>
									</div>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
										dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
										commodo</p>
								</div>
								<div class="review_item reply">
									<div class="media">
										<div class="d-flex">
											<img src="{{ asset('img/product/review-2.png')}}" alt="">
										</div>
										<div class="media-body">
											<h4>Blake Ruiz</h4>
											<h5>12th Feb, 2018 at 05:56 pm</h5>
											<a class="reply_btn" href="#">Reply</a>
										</div>
									</div>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
										dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
										commodo</p>
								</div>
								<div class="review_item">
									<div class="media">
										<div class="d-flex">
											<img src="{{ asset('img/product/review-3.png')}}" alt="">
										</div>
										<div class="media-body">
											<h4>Blake Ruiz</h4>
											<h5>12th Feb, 2018 at 05:56 pm</h5>
											<a class="reply_btn" href="#">Reply</a>
										</div>
									</div>
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
										dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
										commodo</p>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="review_box">
								<h4>Post a comment</h4>
								<form class="row contact_form" action="contact_process.php" method="post" id="contactForm" novalidate="novalidate">
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" class="form-control" id="name" name="name" placeholder="Your Full name">
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input type="email" class="form-control" id="email" name="email" placeholder="Email Address">
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input type="text" class="form-control" id="number" name="number" placeholder="Phone Number">
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<textarea class="form-control" name="message" id="message" rows="1" placeholder="Message"></textarea>
										</div>
									</div>
									<div class="col-md-12 text-right">
										<button type="submit" value="submit" class="btn primary-btn">Submit Now</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<div class="tab-pane fade show active" id="review" role="tabpanel" aria-labelledby="review-tab">
					<div class="row">
						<div class="col-lg-6">
							<div class="row total_rate">
								<div class="col-6">
									<div class="box_total">
										<h5>Overall</h5>
										<h4>{{$overall}}</h4>
										<h6>({{$total_review_count}} Reviews)</h6>
									</div>
								</div>
								<div class="col-6">
									<div class="rating_list">
										<h3>Based on {{$total_review_count}} Reviews</h3>
										<ul class="list">
											<li>
												<a href="#">5 Star 
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star "> </i> {{$review_count_5}}
												</a>
											</li>
											<li>
												<a href="#">4 Star 
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star color_disable"> </i> {{$review_count_4}}
												</a>
											</li>
											<li>
												<a href="#">3 Star 
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star color_disable"></i>
													<i class="fa fa-star color_disable"> </i> {{$review_count_3}}
												</a>
											</li>
											<li>
												<a href="#">2 Star 
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star color_disable"></i>
													<i class="fa fa-star color_disable"></i>
													<i class="fa fa-star color_disable"> </i> {{$review_count_2}}
												</a>
											</li>
											<li>
												<a href="#">1 Star 
													<i class="fa fa-star"></i>
													<i class="fa fa-star color_disable"></i>
													<i class="fa fa-star color_disable"></i>
													<i class="fa fa-star color_disable"></i>
													<i class="fa fa-star color_disable"> </i> {{$review_count_1}}
												</a>
											</li>
											
										</ul>
									</div>
								</div>
							</div>
							<div class="review_list">
								@foreach( $reviews as $view_reviews)
								<div class="review_item">
									<div class="media">
										<div class="d-flex">
											@if($view_reviews->image !=null )
												<img src="{{ asset(Storage::url("upload/user_image/".$view_reviews->image))}}" alt="" width="70px" class="rounded-circle">
											@else
												<img src="{{ asset(Storage::url("upload/user_image/default.png"))}}" alt="" width="70px" class="rounded-circle">
											@endif
										</div>
										<div class="media-body">
											<h4>{{$view_reviews->name}}</h4>

											@for($i = 1; $i <= 5; $i++)
												@if($i > $view_reviews->rating)
													<i class="fa fa-star" style="color:#E8F0F2;"> </i>
												@else
													<i class="fa fa-star"></i>
												@endif
											@endfor
											
											
										</div>
									</div>
									<div class="col-md-12">
										<p>{{$view_reviews->description}}</p>
										@if($view_reviews->image_1 != null)
										<img src="{{ asset(Storage::url("upload/reviews_images/".$view_reviews->image_1))}}" class="img-responsive img-rounded img-thumbnail" style="width:100px" />
										@endif
										@if($view_reviews->image_2 != null)
										<img src="{{ asset(Storage::url("upload/reviews_images/".$view_reviews->image_2))}}" class="img-responsive img-rounded img-thumbnail" style="width:100px" />
										@endif
										@if($view_reviews->image_3 != null)
											<img src="{{ asset(Storage::url("upload/reviews_images/".$view_reviews->image_3))}}" class="img-responsive img-rounded img-thumbnail" style="width:100px" />
										@endif
									</div>
								</div>
								@endforeach
								
							</div>
						</div>
						<div class="col-lg-6">
							<div class="review_box">
								<h4>Add a Review</h4>
								<form class="row contact_form" action="{{url('add-review')}}" method="post" id="contactForm"
								 enctype="multipart/form-data"
								>
									<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">

									<div class="form-group" id="rating-ability-wrapper">
										<p>Your Rating:</p>
										<ul class="list">
										    <div style="display: none">
											    <label class="control-label" for="rating">
											    <br>
											    <span class="field-label-info"></span>
											    <input type="hidden"  name="product_id" value="{{$products->Products_id}}" required="required">
											    </label>
											    <input type="hidden"  name="user_id" value="{{Auth::id()}}" required="required">
											    </label>
											    <input type="hidden" id="selected_rating" name="selected_rating" value="" required="required">
											    </label>

											    <h2 class="bold rating-header" style="">
											    <span class="selected-rating">0</span><small> / 5</small>
											    </h2>
										    </div>

										    <button type="button" class="btnrating btn btn-default btn-lg" data-attr="1" id="rating-star-1">
										        <i class="fa fa-star" aria-hidden="true"></i>
										    </button>
										    <button type="button" class="btnrating btn btn-default btn-lg" data-attr="2" id="rating-star-2">
										        <i class="fa fa-star" aria-hidden="true"></i>
										    </button>
										    <button type="button" class="btnrating btn btn-default btn-lg" data-attr="3" id="rating-star-3">
										        <i class="fa fa-star" aria-hidden="true"></i>
										    </button>
										    <button type="button" class="btnrating btn btn-default btn-lg" data-attr="4" id="rating-star-4">
										        <i class="fa fa-star" aria-hidden="true"></i>
										    </button>
										    <button type="button" class="btnrating btn btn-default btn-lg" data-attr="5" id="rating-star-5">
										        <i class="fa fa-star" aria-hidden="true"></i>
										    </button>
										</div>
										</ul>
										{{-- <p>Outstanding</p> --}}
									<div class="col-md-12">
										<div class="form-group">
											<textarea class="form-control" name="message" id="review_message_id" rows="1" placeholder="Review" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Review'"></textarea></textarea>
										</div>
									</div>
									<div class="col-md-12">
									<div class="form-horizontal">
										<div class="form-group">
											<div id="coba" class="row"> </div>
										
										</div>
									</div>
									</div>
									<div class="col-md-12 error_show_rating" style="display: none" >
										<div class="alert alert-primary" role="alert">Please Enter Product Rating and Review 
										</div>	
									</div>
									
									<div class="col-md-12 text-right">
										@if(Auth::id() !=null)
											<button type="submit" id="submit_form" value="submit" class="primary-btn" style="display: none">Submit Now</button>
											<button type="button" value="submit" class="primary-btn" id="product_review_id" >Submit Now</button>
										
										@else
										<button type="button" onclick="ErrorAlert()" class="primary-btn">Submit Now</button>
										@endif
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================End Product Description Area =================-->


@endsection
@section('activate')
<script>
     ActiveMenu(5);
</script>
@endsection