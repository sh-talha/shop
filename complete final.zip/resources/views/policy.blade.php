@extends('website_layout.layout')
@section('body')
<!-- Start Banner Area -->
<section class="banner-area organic-breadcrumb">
    <div class="container">
    </div>
</section>

<!--================Login Box Area =================-->
	<section class="login_box_area section_gap" style="margin-top: -150px !important">
		<div class="container">
			<h2 style="text-align:center;" >Privacy and Policy</h2>
			<div class="row">
				<div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
				    <h1 style="text-align: center;"><strong><span style="line-height: 107%; font-size: 16px;">VARIOS</span></strong></h1>

				    <p><br></p>
				    <ul style="margin-bottom:0cm;list-style-type: disc;">
				        <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><strong><span style="line-height:107%;font-size:19px;">Gastos de envi&oacute;</span></strong></li>
				    </ul>
				</div>

				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:70.8pt;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style="font-size:16px;line-height:107%;">En Granyupon.com tenemos una pol&iacute;tica transparente en gastos de envi&oacute;. Como norma general y estandarizada se cargar&aacute; <strong>5,95&euro; en concepto de gastos de envi&oacute;, ya sea por un producto, como por m&uacute;ltiples productos.</strong> Somos conscientes de que siempre no podr&aacute;, ni es viable esta tarifa estandarizada, por lo que nos reservamos el derecho de aumentar esta cuant&iacute;a, si el vendedor lo pide expresamente y por motivos justificados. No Obstante, siempre comunicaremos esto al comprador antes de realizar el pedido.</span></p>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><strong><span style="font-size:19px;line-height:107%;">&nbsp;</span></strong></p>
				<div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
				    <ul style="margin-bottom:0cm;list-style-type: disc;">
				        <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><strong><span style="line-height:107%;font-size:19px;">Pol&iacute;tica de devoluciones</span></strong></li>
				    </ul>
				</div>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:.0001pt;margin-left:70.8pt;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style="font-size:16px;line-height:107%;">Granyupon.com no ofrece, ni se hace cargo de devoluciones, ya sea por cambios o retorno de dinero. Esto es as&iacute; por la sencilla raz&oacute;n de que granyupon.com no comercializa (no compra, ni vende) dichos productos, por lo tanto y atendiendo a los t&eacute;rminos y condiciones, que tanto el usuario como el vendedor se acogen y aceptan al momento de crear cuentas en el portal eximen a granyupon.com de toda responsabilidad, referente a la devoluci&oacute;n y garant&iacute;a de dichos productos u anuncios, quedando estas en manos del comprador y el vendedor.</span></p>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:.0001pt;margin-left:70.8pt;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style="font-size:16px;line-height:107%;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;No obstante, y con la intenci&oacute;n de ayudar siempre, el comprador podr&aacute; abrir una disputa con el vendedor siempre que este lo requiera y por motivos referentes siempre a una compra realizada a este &uacute;ltimo, en la cual Granyupon.com intentar&aacute; mediar con el fin de arreglar el problema y que las dos partes (comprador y vendedor) queden lo mas satisfechas posibles.</span></p>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:.0001pt;margin-left:70.8pt;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style="font-size:16px;line-height:107%;">&nbsp;</span></p>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:70.8pt;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style="font-size:16px;line-height:107%;">Dicho lo cual es importante que antes de realizar cualquier compra hayamos le&iacute;do bien la descripci&oacute;n de los productos y sus pol&iacute;ticas de devoluci&oacute;n o envi&oacute;, a fin de minimizar los malentendidos u errores que podr&iacute;an surgir en el futuro.</span></p>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><strong><span style="font-size:19px;line-height:107%;">&nbsp;</span></strong></p>
				<div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
				    <ul style="margin-bottom:0cm;list-style-type: disc;">
				        <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><strong><span style="line-height:107%;font-size:19px;">Contacto</span></strong></li>
				    </ul>
				</div>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:.0001pt;margin-left:70.8pt;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style="font-size:16px;line-height:107%;">Siempre puedes ponerte en contacto con nosotros en: <strong><a href="mailto:info@granyupon.com">info@granyupon.com</a>&nbsp;</strong>y estaremos encantados de atender cualquier duda o problema que te haya surgido. Como norma general nos pondremos en contacto contigo en un plazo entre 6h o 48h.</span></p>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:70.8pt;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style="font-size:16px;line-height:107%;">&nbsp;</span></p>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><strong><span style="font-size:19px;line-height:107%;">&nbsp;</span></strong></p>
				<div style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'>
				    <ul style="margin-bottom:0cm;list-style-type: disc;">
				        <li style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:0cm;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><strong><span style="line-height:107%;font-size:19px;">Pago seguro</span></strong></li>
				    </ul>
				</div>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:.0001pt;margin-left:36.0pt;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style="font-size:16px;line-height:107%;">&nbsp;</span></p>
				<p style='margin-top:0cm;margin-right:0cm;margin-bottom:8.0pt;margin-left:70.8pt;line-height:107%;font-size:15px;font-family:"Calibri",sans-serif;'><span style="font-size:16px;line-height:107%;">Los pagos realizados dentro del portal son 100% seguros. Granyupon.com no guarda datos de tarjeta en ning&uacute;n caso ni sede a terceros esta informaci&oacute;n. Por otro lado, siempre aconseja no pagar por transferencia ni ning&uacute;n otro m&eacute;todo ajeno a este portal a ning&uacute;n vendedor. Si alg&uacute;n vendedor te pide que realices una transferencia o pago fuera de este portal, recuerda que puedes correr un gran riesgo, te aconsejamos encarecidamente que no lo hagas.</span></p>
			</div>
		</div>
	</section>

@endsection
