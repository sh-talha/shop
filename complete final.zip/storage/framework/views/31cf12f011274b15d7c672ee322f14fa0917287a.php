
<td>
	<?php
		if ($entry->{$column['entity']}) {
	    	echo $entry->{$column['entity']}->{$column['attribute']};
	    }
	?>
</td>
